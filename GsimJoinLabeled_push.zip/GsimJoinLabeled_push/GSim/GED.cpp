#include "GED.h"
#include <fstream>



int main()
{
        cout<<"Started Execution \n";
ofstream oup;
oup.open("data_vrtx_label_all_ged.txt");
Preprocess_GED("data_vrtx_label_gsim.txt", 4,5);
cout<<" Preprocess_GED Done \n";
int ans=0;
for(int i=0;i<2;i++)
for(int j=i;j<2;j++){
        if(i==j)continue;
	cout<<"Getting GED \n";
        int e=Get_GED(i,j);
        oup<<i<<" "<<j<<" "<<e<<endl;
        if(e<=5)
        ans++;
}cout<<"count of pairs having GED <=5 " <<ans<<"\n";


Clean_GED();
        return 0;
}


