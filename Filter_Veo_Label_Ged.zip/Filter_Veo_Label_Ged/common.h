#pragma once

#include<iostream>
#include<fstream>
#include<vector>
#include<unordered_set>
#include<unordered_map>
#include<algorithm>
#include<functional>
#include<math.h>
#include<string>
#include<algorithm>
#include<sys/time.h>
#include<sys/stat.h>
#include<sys/types.h>

#include<sys/resource.h>
#include<time.h>
#include<chrono>

using namespace std;



