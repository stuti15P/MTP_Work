/*#include "GED.h"




int main() 
{
Preprocess_GED("data_2k.txt", 4,5);
int ans=0;
for(int i=0;i<2193;i++)
for(int j=0;j<2193;j++){
	if(i==j)continue;
	int e=Get_GED(i,j);
	if(e<=5)
	ans++;
}cout<<ans<<"\n";


Clean_GED();
	return 0;
}
*/